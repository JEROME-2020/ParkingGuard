

// document.addEventListener('DOMContentLoaded', () => {

//     const db = firebase.firestore();
//     const parkingslotA = elements('parkingslotA');
//     const parkingslotB = elements('parkingslotB');

//     parkingslotA.innerHTML = '';
//      parkingslotB.innerHTML = '';

//      db.collection('parking_slot')
//      .where('parking_type', '==', 'Car')
//      .where('zone', '==', 'First_zone')
//      .orderBy('area', 'asc')
//      .onSnapshot(snap => {   

//       let slot = 0;
//       let parked = 0;
    
//     snap.forEach(doc => {

//        const d = doc.data();

//        if(d.area == 'A'){
//           if(d.status == 1){
//                 parkingslotA.innerHTML += `<div class="slot occupied" onclick="bookSlot(this)" title='Plate No: ${d.plate_number}'></div>
//                 `;
//           }else{
//                 parkingslotA.innerHTML += `<div class="slot available" onclick="bookSlot(this)">${d.area + "-" + d.parking_number}</div>
//                 <input type='text' value='${doc.id}' id='doc_id'>
//                 `;
//           }
//        }
//        if(d.area == 'B'){
//             if(d.status == 1){
//                 parkingslotB.innerHTML += `<div class="slot occupied" onclick="bookSlot(this)" title='Plate No: ${d.plate_number}'></div>
//                 `;
//               }else{
//                 parkingslotB.innerHTML += `<div class="slot available" onclick="bookSlot(this)">${d.area + "-" + d.parking_number}</div>
//                 <input type='text' value='${doc.id}' id='doc_id'>`;
//             }
//        }
    

//       if(d.status == 0){
//         slot += 1;
//       }else{
//         parked += 1;
//       }

//     });

//     elements('sltp-count-slot').innerHTML = slot;
//     elements('park-count').innerHTML = parked;


//   });

  
// });
function $(id) { return document.getElementById(id); }

document.addEventListener('DOMContentLoaded', () => {
  const db = firebase.firestore();
  const parkingslotA = $('parkingslotA');
  const parkingslotB = $('parkingslotB');

  // Clear current UI
  parkingslotA.textContent = '';
  parkingslotB.textContent = '';

  db.collection('parking_slot')
    .where('parking_type', '==', 'Car')
    .where('zone', '==', 'First_zone')
    .orderBy('area', 'asc')
    .onSnapshot((snap) => {
      let slot = 0;
      let parked = 0;

      // Rebuild UI from scratch to keep it simple
      parkingslotA.textContent = '';
      parkingslotB.textContent = '';

      snap.forEach((doc) => {
        const d = doc.data();

        const div = document.createElement('div');
        div.classList.add('slot');

        if (d.status === 1) {
          // occupied
          div.classList.add('occupied');
          div.title = `Plate No: ${d.plate_number}`;
          div.textContent = ''; // same as your original UI
        } else {
          // available
          div.classList.add('available');
          div.dataset.docId = doc.id; // attach Firestore doc id
          div.textContent = `${d.area}-${d.parking_number}`;
        }

        if (d.area === 'A') {
          parkingslotA.appendChild(div);
        } else if (d.area === 'B') {
          parkingslotB.appendChild(div);
        }

        if (d.status === 0) slot += 1;
        else parked += 1;
      });

      $('sltp-count-slot').textContent = slot;
      $('park-count').textContent = parked;
    });

  // Event delegation for booking clicks (no inline onclick)
  document.addEventListener('click', async (evt) => {
    const slotEl = evt.target.closest('.slot.available');
    if (!slotEl) return; // clicked elsewhere

    await bookSlot(slotEl);
  });
});


$('submit-parking-filter').addEventListener('click', async (e) => {

   if (e && typeof e.preventDefault === 'function') e.preventDefault();

    const zone = $('zone-filter').value.trim();
    const parking_type = $('vehicle-type').value.trim();
    const db = firebase.firestore();

     parkingslotA.innerHTML = '';
     parkingslotB.innerHTML = '';

    try {
          const snap = await db
            .collection('parking_slot')
            .where('zone', '==', zone)
            .where('parking_type', '==', parking_type)
            .get();

          if (snap.empty) {
            console.warn('No parking slots found for filters:');
          }

          let slot = 0;
          let parked = 0;

            snap.forEach(doc => {

          const d = doc.data();

          if(d.area == 'A'){

              if(d.status == 1){
                parkingslotA.innerHTML += `<div class="slot occupied" onclick="bookSlot(this)" title='Plate No: ${d.plate_number}'></div>`;
              }else{
                parkingslotA.innerHTML += `<div class="slot available" onclick="bookSlot(this)">${d.area + "-" + d.parking_number}</div>
                 <input type='hidden' value='${doc.id}' id='doc_id'>`;
              }
              
          }
          if(d.area == 'B'){
              
               if(d.status == 1){
                parkingslotB.innerHTML += `<div class="slot occupied" onclick="bookSlot(this)" title='Plate No: ${d.plate_number}'></div>`;
              }else{
                parkingslotB.innerHTML += `<div class="slot available" onclick="bookSlot(this)">${d.area + "-" + d.parking_number}</div>
                 <input type='hidden' value='${doc.id}' id='doc_id'>`;
              }
              
          }
        

          if(d.status == 0){
            slot += 1;
          }else{
            parked += 1;
          }

        });

        elements('sltp-count-slot').innerHTML = slot;
        elements('park-count').innerHTML = parked;
          

          
        } catch (err) {
          console.error('Error fetching parking slots:', err);
          throw err;
        }

          
 
  
});




// function bookSlot(element) {

//     if (!element.classList.contains('available')) return; // Only act on available slots

//     const slotName = element.innerText.trim();

//     const doc_id = document.querySelector('.doc_id').value.trim();

//     // Show a confirmation dialog
//     const ok = confirm(`Book parking slot ${slotName}?`);
//     if (!ok) return; // User chose "No"
    

//     // Proceed to book
//     element.classList.remove('available');
//     element.classList.add('occupied');

//     // Optional alert/log
//     console.log(`Slot ${slotName} Booked!${doc_id}`);
// }



// function bookSlot(element) {

//     if (!element.classList.contains('available')) return;

//     const slotName = element.innerText.trim();
//     const doc_id = document.querySelectorAll('#doc_id').value.trim();
//     const userInput = prompt(`Enter plate number before booking slot ${slotName}:`);

//     if (userInput === null) {
//           return;
//     }
//     if (userInput.trim() === "") {
//         alert("Input is required!");
//         return;
//     }else{  

//         const db = firebase.firestore();
//         const update_lot = db.collection('parking_slot').doc(doc_id);
//         update_lot.update({
//           plate_number: userInput,
//           status: 1
//         });

     

//         element.classList.remove('available');
//         element.classList.add('occupied');

//            console.log(doc_id);


//     }

  

//   }


async function bookSlot(element) {
  const slotName = element.textContent.trim();
  const docId = element.dataset.docId;

  if (!docId) {
    console.error('Missing doc id on slot element');
    alert('Something went wrong. Please refresh and try again.');
    return;
  }

  const userInput = prompt(`Enter plate number before booking slot ${slotName}:`);
  if (userInput === null) return;          // user cancelled
  const plate = userInput.trim();
  if (!plate) {
    alert('Input is required!');
    return;
  }

  try {
    const db = firebase.firestore();
    await db.collection('parking_slot').doc(docId).update({
      plate_number: plate,
      status: 1
    });

    // Optimistic UI update to reflect booking
    element.classList.remove('available');
    element.classList.add('occupied');
    element.title = `Plate No: ${plate}`;
    element.textContent = '';
    delete element.dataset.docId;

    console.log('Booked doc:', docId);
  } catch (err) {
    console.error('Failed to update slot:', err);
    alert('Failed to book the slot. Please try again.');
  }
}
