
function elements(e) {
    return document.getElementById(e);
}

const input = elements("parking-number");
  elements("btnPlus").addEventListener("click", () => {
    input.value = Number(input.value || 0) + 1;
});
 

document.addEventListener('DOMContentLoaded', () => {

  const db = firebase.firestore();
  const tbody = document.querySelector('#parkingTable tbody');

  db.collection('parking_slot')
  .orderBy('area', 'asc')
  .onSnapshot(snap => {

    tbody.innerHTML = ''; 
    let iconvi = '';
    let status = '';


    snap.forEach(doc => {

      const d = doc.data();
     if(d.parking_type == 'Car'){
        iconvi = "<image src='../images/car.png' width='50px'><image>";
     }
     else if(d.parking_type == 'Motorcycle'){
        iconvi = "<image src='../images/Motor.png' width='50px'><image>";
     }

     else if(d.parking_type == 'Bicycle'){
        iconvi = "<image src='../images/bike.png' width='50px'><image>";
     }

     if(d.status == 1){
        status = "<image src='../images/parked.png' width='50px'><image>";
     }else{
        status = "<image src='../images/availp.png' width='50px'><image>";
     }

      tbody.innerHTML += `
        <tr>
          <td>${d.area + "-" + d.parking_number}</td>
          <td>${iconvi}</td>
          <td>
            <span class="plate-icon" background="red" aria-label="Plate number XXX-000">${d.plate_number}</span>
          </td>
          <td>${status}</td>
          <td>${d.zone}</td>
           <td>
             <button class="btn-edit btn-custom" onclick="editV(event, '${doc.id}')">Edit</button>
          </td>
          <td>
            <button class="btn-delete btn-custom" onclick="deleteV(event, '${doc.id}')">Delete</buttonz>
          </td>
        </tr>`;


    });
  });

});


elements('register-btn').addEventListener('click', async (e) => {
  
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
      const db = firebase.firestore();
      const parking_validator = elements('parking-validator').value.trim();

      if(parking_validator == 1){

          const zone = elements('zone').value.trim();
          const parking_type = elements('parking-type').value.trim();
          const area = elements('area').value.trim();
          const parking_number_raw = elements('parking-number').value.trim();
          const plate_number = 'N/A';
          const status = 0;
          
          const current_p_number = elements('current-p-number').value.trim();
      
          let latesvalue = (parking_number_raw - current_p_number);

          
          if(latesvalue == 0){
            alert('Please click add to replace the current value');
          }else{
            
            try {
              
              const parking_number = parseInt(parking_number_raw, 10);

              if (!Number.isInteger(parking_number)) {
                throw new Error('Parking number must be an integer.');
              }

              await db.collection('parking_slot').add({
                zone,
                parking_type,
                area,
                parking_number,  // guaranteed integer here
                plate_number,
                status
              });

              alert('Successfully registered');
            } catch (e) {
              alert('You have an Error: ' + e.message);
            }


          }

        
      }else{
          alert('You are not allow to insert please select filters');
      }
  

});


elements('filter-btn').addEventListener('click', async (e) => {

      if (e && typeof e.preventDefault === 'function') e.preventDefault();

        const db = firebase.firestore();

        const zone = elements('zone').value.trim();
        const parking_type = elements('parking-type').value.trim();
        const area = elements('area').value.trim();

        try {
          const snap = await db
            .collection('parking_slot')
            .where('zone', '==', zone)
            .where('parking_type', '==', parking_type)
            .where('area', '==', area)
            .get();

          if (snap.empty) {
            console.warn('No parking slots found for filters:');
          }

          
          const results = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

          const current = results;

         elements('parking-number').value = results.length;
         elements('parking-validator').value = 1;
         elements('current-p-number').value = current.length;
         
        
          return results;

          
        } catch (err) {
          console.error('Error fetching parking slots:', err);
          throw err;
        }



});


