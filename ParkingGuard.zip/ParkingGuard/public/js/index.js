
function elements(e) {
    return document.getElementById(e);
}

const signUp = elements('submit-btn');

signUp.addEventListener('click', (e) => {

    e.preventDefault();

    const firstname = elements('firstname').value;
    const lastname = elements('lastname').value;
    const email = elements('email').value;
    const password = elements('password').value;

    if (isEmpty(firstname) || isEmpty(lastname) || isEmpty(email) || isEmpty(password)) {
        alert('Please fill out the require fields');
    }else{
        
        const db = firebase.firestore();
        const auth = firebase.auth();

        auth.createUserWithEmailAndPassword(email, password)
            .then(() => { 
                db.collection('users').add({
                    firstname: firstname,
                    lastname: lastname,
                    email: email,
                    created_at: firebase.firestore.FieldValue.serverTimestamp()
                })
                .then((docRef) => {
                    alert('The account successfully regiter');
                })
                .catch((error) => {
                    handleAuthError(error);
                });     

            })
            .catch((error) => {
                handleAuthError(error);
            });
    }


});

function isEmpty(v) {
  return v == null || v.trim() === '';
}





// function elements(e){
//     return document.getElementById(e);
// }

// const signUp = elements('submit-btn');

// signUp.addEventListener('click', (e) =>{

//     e.preventDefault();
//     const firstname = elements('firstname').value;
//     const lastname = elements('lastname').value;
//     const email = elements('email').value;
//     const password = elements('password').value;


  
//     const db = firebase.firestore();


//     firebase.auth().createUserWithEmailAndPassword(email, password)
//     showMessage('Account Successfully created', 'signup-message');



// });

    // db.collection('users').add({
    //     email: email,   // example input fields
    //     firstname: firstname,
    //     lastname: lastname
  
    // })
    // .then((docRef) => {
    //     showMessage("Document inserted with ID:" + docRef.id, 'signup-message');
        
    // })
    // .catch((error) => {

    //   showMessage("Error adding document: " + docRef.id, 'signup-message');
    
    // });

  
    //   const docRef = doc(db, "users", user.uid);
    //   setDoc(docRef, userData).then(()=>{
    //      window.location.href = 'index.html';
    //   }).catch((error)=>{ 
    //     console.log('The insert document is error', error);
    // }).catch((error)=>{

   
      
    


//});








// function register(){

//     const firstname = elements('firstname').value;
//     const lastname = elements('lastname').value;
//     const email = elements('email').value;
//     const password = elements('password').value;

//     try {

//         const insert = firebase.auth().createUserWithEmailAndPassword(email, password);
//         const displayName = [firstname, lastname].filter(Boolean).join(' ').trim();
//         if (displayName) {
//             insert.user.updateProfile({ displayName });
//         }

//         alert('Registration successful!');
//         console.log('Registered user:', cred.user.uid, cred.user.email);


//     } catch (e) {
//           handleAuthError(e);
        
//     }


// }


//   // ===== Login =====
//   function login() {
   
//      const email = elements('email').value;
//     const password = elements('password').value;


//     if (!email || !password) {
//       alert('Email and password are required.');
//       return;
//     }

//     try {
//       const cred = firebase.auth().signInWithEmailAndPassword(email, password);
      
      

//       document.writeln(`successfully login user ${cred.user}`);

//     } catch (err) {
//       console.log(err);
//     }


// //  const provider = new firebase.auth.GoogleAuthProvider();

// //     firebase.auth().signInWithPopup(provider)

// //         .then(result => {
// //             const user = result.user;
// //             document.writeln(`Hello ${user.displayName}`);
// //             console.log();
// //         })
// //         .catch(console.log());



//   }

  
//   // ===== Logout =====
//   async function logout() {
//     try {
//       await firebase.auth().signOut();
//     } catch (err) {
//       alert(err.message || 'Failed to sign out.');
//     }
//   }

//   // ===== Password reset =====
//   async function sendReset() {
//     const email = (el('email')?.value || '').trim();
//     if (!email) {
//       alert('Enter your email to receive a reset link.');
//       return;
//     }
//     try {
//       await firebase.auth().sendPasswordResetEmail(email);
//       alert('Password reset email sent.');
//     } catch (err) {
//       handleAuthError(err);
//     }
//   }

//   // ===== Email verification =====
//   async function verifyEmail() {
//     const user = firebase.auth().currentUser;
//     if (!user) {
//       alert('You must be signed in to verify your email.');
//       return;
//     }
//     try {
//       await user.sendEmailVerification();
//       alert('Verification email sent.');
//     } catch (err) {
//       handleAuthError(err);
//     }
//   }

//   // ===== Friendly error helper =====
  function handleAuthError(err) {
    console.error('Auth error:', err);
    const code = err?.code || '';
    if (code === 'auth/email-already-in-use') {
      alert('That email is already in use.');
    } else if (code === 'auth/weak-password') {
      alert('Password is too weak (min 6 chars).');
    } else if (code === 'auth/invalid-email') {
      alert('Please enter a valid email address.');
    } else if (code === 'auth/user-not-found' || code === 'auth/wrong-password') {
      alert('Incorrect email or password.');
    } else {
      alert(err?.message || 'Authentication failed.');
    }
  }



