
function $(id) { return document.getElementById(id); }

document.addEventListener('DOMContentLoaded', () => {
  const db = firebase.firestore();
  const parkingslotA = $('parkingslotA');
  const parkingslotB = $('parkingslotB');

  // Clear current UI
  parkingslotA.textContent = '';
  parkingslotB.textContent = '';

  db.collection('parking_slot')
    .where('parking_type', '==', 'Car')
    .where('zone', '==', 'First_zone')
    .orderBy('area', 'asc')
    .onSnapshot((snap) => {
      let slot = 0;
      let parked = 0;

      parkingslotA.textContent = '';
      parkingslotB.textContent = '';

      snap.forEach((doc) => {
        const d = doc.data();

        const div = document.createElement('div');
        div.classList.add('slot');

        if (d.status === 1) {

          if(d.parking_type == 'Car'){
            div.classList.add('occupiedCar');
          }
          if(d.parking_type == 'Motorcycle'){
            div.classList.add('occupiedMotor');
          }
          if(d.parking_type == 'Bicycle'){
            div.classList.add('occupiedBike');
          }

          div.title = `Plate No: ${d.plate_number}`;
          div.textContent = ''; 


        } else {
          // available
          div.classList.add('available');
          div.dataset.docId = doc.id; // attach Firestore doc id
          div.textContent = `${d.area}-${d.parking_number}`;
        }

        if (d.area === 'A') {
          parkingslotA.appendChild(div);
        } else if (d.area === 'B') {
          parkingslotB.appendChild(div);
        }

        if (d.status === 0) slot += 1;
        else parked += 1;
      });

      $('sltp-count-slot').textContent = slot;
      $('park-count').textContent = parked;
    });

  // Event delegation for booking clicks (no inline onclick)
  document.addEventListener('click', async (evt) => {
    const slotEl = evt.target.closest('.slot.available');
    if (!slotEl) return; // clicked elsewhere

    await bookSlot(slotEl);
  });
});


$('submit-parking-filter').addEventListener('click', async (e) => {

   if (e && typeof e.preventDefault === 'function') e.preventDefault();

    const zone = $('zone-filter').value.trim();
    const parking_type = $('vehicle-type').value.trim();
    const db = firebase.firestore();

    const parkingslotA = $('parkingslotA');
    const parkingslotB = $('parkingslotB');

    parkingslotA.innerHTML = '';
    parkingslotB.innerHTML = '';

    try {
          const snap = await db
            .collection('parking_slot')
            .where('zone', '==', zone)
            .where('parking_type', '==', parking_type)
            .orderBy('area', 'asc')
            .get();

          if (snap.empty) {
            console.warn('No parking slots found for filters:');
          }

          let slot = 0;
          let parked = 0;

        snap.forEach((doc) => {
        const d = doc.data();

        const div = document.createElement('div');
        div.classList.add('slot');

        if (d.status === 1) {
          
          if(d.parking_type == 'Car'){
            div.classList.add('occupiedCar');
          }
          if(d.parking_type == 'Motorcycle'){
            div.classList.add('occupiedMotor');
          }
          if(d.parking_type == 'Bicycle'){
            div.classList.add('occupiedBike');
          }

          div.title = `Plate No: ${d.plate_number}`;
          div.textContent = '';
        } else {
   
          div.classList.add('available');
          div.dataset.docId = doc.id; 
          div.textContent = `${d.area}-${d.parking_number}`;
        }

        if (d.area === 'A') {
          parkingslotA.appendChild(div);
        } else if (d.area === 'B') {
          parkingslotB.appendChild(div);
        }

        console.log(d.status);

        if (d.status == 0){
          slot += 1;
        }
        else{
          parked += 1;

        } 
  });

        elements('sltp-count-slot').innerHTML = slot;
        elements('park-count').innerHTML = parked;

         // Event delegation for booking clicks (no inline onclick)
        document.addEventListener('click', async (evt) => {
          const slotEl = evt.target.closest('.slot.available');
          if (!slotEl) return; // clicked elsewhere

          await bookSlot(slotEl);
        });
          

          
        } catch (err) {
          console.error('Error fetching parking slots:', err);
          throw err;
        }

          
 
  
});



async function bookSlot(element) {
  const slotName = element.textContent.trim();
  const docId = element.dataset.docId;

  if (!docId) {
    console.error('Missing doc id on slot element');
    alert('Something went wrong. Please refresh and try again.');
    return;
  }

  const userInput = prompt(`Enter plate number before booking slot ${slotName}:`);
  if (userInput === null) return;          // user cancelled
  const plate = userInput.trim();
  if (!plate) {
    alert('Input is required!');
    return;
  }

  try {
    const db = firebase.firestore();
    await db.collection('parking_slot').doc(docId).update({
      plate_number: plate,
      status: 1
    });

    // Optimistic UI update to reflect booking
    element.classList.remove('available');
    element.classList.add('occupied');
    element.title = `Plate No: ${plate}`;
    element.textContent = '';
    delete element.dataset.docId;

    console.log('Booked doc:', docId);
  } catch (err) {
    console.error('Failed to update slot:', err);
    alert('Failed to book the slot. Please try again.');
  }
}
