
function $(e) {
    return document.getElementById(e);
}

const registerBtn = $('edit-btn');

registerBtn.addEventListener('click', async (e) => {
  e.preventDefault();
  const db = firebase.firestore();
  const firstname = $('First_name').value.trim();
  const lastname = $('Last_name').value.trim();
  const action_item = $('action-item').value.trim();

  const isEmpty = v => !v || v.length === 0;
  if (isEmpty(firstname) || isEmpty(lastname)) {
    alert('Please fill out the required fields');
    return;
  }

    try {
      await db.collection('users').doc(action_item).update({
        firstname,
        lastname
      });

      alert("Updated successfully.");
    } catch (err) {
      alert("Error: " + err.message);
    }


});


// ===== Friendly error helper =====
function isEmpty(v) {
  return v == null || v === '';
}

document.addEventListener('DOMContentLoaded', () => {
  const db = firebase.firestore();
  const tbody = document.querySelector('#vehicleTable tbody');
  

  db.collection('users').orderBy('email', 'desc').onSnapshot(snap => {
    tbody.innerHTML = ''; // clear table

    snap.forEach(doc => {
      const d = doc.data();
      tbody.innerHTML += `
        <tr>
          <td>${d.email || ''}</td>
          <td>${d.firstname || ''}</td>
          <td>${d.lastname || d.vihicle_name || ''}</td>
          <td>${formatYYYYMMDDHHmm(d.created_at) || ''}</td>
          <td>
             <button class="btn-edit btn-custom" onclick="editUser(event, '${d.email}')">Edit</button>
          </td>
          <td>
            <button class="btn-delete btn-custom" onclick="deleteUser(event, '${d.email}')">Delete</buttonz>
          </td>
        </tr>
      `;
    });

    
  });
});



function formatYYYYMMDDHHmm(created_at) {
  const date = (created_at?.toDate?.()) ? created_at.toDate() : new Date(created_at);
  if (isNaN(date)) return '';
  const pad = (n) => String(n).padStart(2, '0');
  return [
    date.getFullYear(),
    pad(date.getMonth()+1),
    pad(date.getDate())
  ].join('-') + ' ' + [pad(date.getHours()), pad(date.getMinutes())].join(':');
}


async function editUser(e, email) {

  if (e && typeof e.preventDefault === 'function') e.preventDefault();
  const db = firebase.firestore();
  
  try {
    const snap = await db
      .collection('users')
      .where('email', '==', email)
      .get();

    if (snap.empty) {
      console.warn('No users found for email: ', email);
      return;
    }

    const doc = snap.docs[0];
    const data = doc.data();

    console.log(data);

    $('First_name').value = data.firstname;   
    $('Last_name').value = data.lastname;    
    $('action-item').value = doc.id;   
 
  } catch (err) {
    console.error('Error fetching vehicle:', err);
  }
}

async function deleteUser(e, email) {
  
  if (e && typeof e.preventDefault === 'function') e.preventDefault();
  const db = firebase.firestore();

  try {
    const data = await db.collection('users')
      .where('email', '==', email)
      .limit(1) 
      .get();

    if (data.empty) {
      console.warn('No user found for email:', email);
      return;
    }

    const doc = data.docs[0]; 
    const confirmed = window.confirm(
      `Are you sure you want to delete this item?\nPlate: ${email}`
    );

    if (!confirmed) {
      console.log('Canceled');
      return;
    }

    await doc.ref.delete();
    console.log(`users deleted successfully. ID: ${doc.id}, Plate: ${email}`);

  } catch (err) {
    console.error('Error deleting vehicle:', err);
  }
}

