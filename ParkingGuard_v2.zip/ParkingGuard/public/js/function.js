
function elements(e) {
    return document.getElementById(e);
}

const registerBtn = elements('register-btn');

registerBtn.addEventListener('click', async (e) => {
  e.preventDefault();
  const db = firebase.firestore();
  const name = elements('name').value.trim();
  const vehicle_type = elements('vehicle-type').value.trim();
  const vehicle_name = elements('vehicle-name').value.trim();
  const plate_number = elements('plate-number').value.trim().toUpperCase(); // normalize
  const action_item = elements('action-item').value.trim();

  const isEmpty = v => !v || v.length === 0;
  if (isEmpty(name) || isEmpty(vehicle_type) || isEmpty(vehicle_name) || isEmpty(plate_number)) {
    alert('Please fill out the required fields');
    return;
  }

if(action_item == 0){

   try {

    const snap = await db.collection('vehicle')
      .where('plate_number', '==', plate_number)
      .limit(1)
      .get();

    if (!snap.empty) {
      alert('This plate number is already registered.');
      return;
    }

    await db.collection('vehicle').add({
      name,
      vehicle_type,   // keep keys as your current schemale
      vehicle_name,
      plate_number,   // stored normalized (uppercase)
      created_at: firebase.firestore.FieldValue.serverTimestamp()
    });

    alert('The vehicle was successfully registered.');
  } catch (err) {
    alert('Error: ' + err.message);
  }


}else{

    try {
      await db.collection('vehicle').doc(action_item).update({
        name,
        vehicle_type,
        vehicle_name,
        plate_number,
        updated_at: firebase.firestore.FieldValue.serverTimestamp()
      });

      alert("Updated successfully.");
    } catch (err) {
      alert("Error: " + err.message);
    }


}


});


// ===== Friendly error helper =====
function isEmpty(v) {
  return v == null || v === '';
}

document.addEventListener('DOMContentLoaded', () => {
  const db = firebase.firestore();
  const tbody = document.querySelector('#vehicleTable tbody');

  db.collection('vehicle').orderBy('plate_number', 'desc').onSnapshot(snap => {
    tbody.innerHTML = ''; // clear table

    snap.forEach(doc => {
      const d = doc.data();
      tbody.innerHTML += `
        <tr>
          <td>${d.name || ''}</td>
          <td>${d.vehicle_type || d.vihicle_type || ''}</td>
          <td>${d.vehicle_name || d.vihicle_name || ''}</td>
          <td>${d.plate_number || ''}</td>
          <td>
             <button class="btn-edit btn-custom" onclick="editV(event, '${d.plate_number}')">Edit</button>
          </td>
          <td>
            <button class="btn-delete btn-custom" onclick="deleteV(event, '${d.plate_number}')">Delete</buttonz>
          </td>
        </tr>
      `;
    });
  });
});


async function editV(e, plateNumber) {

  if (e && typeof e.preventDefault === 'function') e.preventDefault();
  const db = firebase.firestore();
  
  try {
    const snap = await db
      .collection('vehicle')
      .where('plate_number', '==', plateNumber)
      .get();

    if (snap.empty) {
      console.warn('No vehicle found for plate:', plateNumber);
      return;
    }

    const doc = snap.docs[0];
    const data = doc.data();

    elements('name').value = data.name;   
    elements('vehicle-type').value = data.vehicle_type;   
    elements('vehicle-name').value = data.vehicle_name; 
    elements('plate-number').value = data.plate_number;  
    elements('action-item').value = doc.id;
    elements('title-action').innerHTML = "Edit Vehicle";
    elements('register-btn').innerHTML = "Edit Vehicle";       
 
  } catch (err) {
    console.error('Error fetching vehicle:', err);
  }
}

async function deleteV(e, plateNumber) {
  
  if (e && typeof e.preventDefault === 'function') e.preventDefault();
  const db = firebase.firestore();

  try {
    const data = await db.collection('vehicle')
      .where('plate_number', '==', plateNumber)
      .limit(1) 
      .get();

    if (data.empty) {
      console.warn('No vehicle found for plate:', plateNumber);
      return;
    }

    const doc = data.docs[0]; 
    const confirmed = window.confirm(
      `Are you sure you want to delete this item?\nPlate: ${plateNumber}`
    );

    if (!confirmed) {
      console.log('Canceled');
      return;
    }

    await doc.ref.delete();
    console.log(`Vehicle deleted successfully. ID: ${doc.id}, Plate: ${plateNumber}`);

  } catch (err) {
    console.error('Error deleting vehicle:', err);
  }
}

