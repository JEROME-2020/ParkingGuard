
function elements(e) {
    return document.getElementById(e);
}

const signUp = elements('submit-btn');
const goLogin = elements('submit-login');



if(!isEmpty(goLogin)){

  goLogin.addEventListener('click', (e) =>{

    e.preventDefault();
    const email = elements('email').value;
    const password = elements('password').value;

    if(!isEmpty(email) && !isEmpty(password)){
    
        const auth = firebase.auth();
        auth.signInWithEmailAndPassword(email, password).then((userCredential)=>{

          const user = userCredential.user;
          const email = user.email;
          const uid = user.uid;

          
          if(!isEmpty(uid) && isEmpty(email)){
            window.location.href = 'home.html';
          }


        }).catch((error) => {
          handleAuthError(error);
        });


    }else{
      alert('Please fill out required field');
    }
    
    
  });
}


if(!isEmpty(signUp)){
  
signUp.addEventListener('click', (e) => {

    e.preventDefault();

    const firstname = elements('firstname').value;
    const lastname = elements('lastname').value;
    const email = elements('email').value;
    const password = elements('password').value;

    if (isEmpty(firstname) || isEmpty(lastname) || isEmpty(email) || isEmpty(password)) {
        alert('Please fill out the require fields');
    }else{
        
        const db = firebase.firestore();
        const auth = firebase.auth();

        auth.createUserWithEmailAndPassword(email, password)
            .then(() => { 
                db.collection('users').add({
                    firstname: firstname,
                    lastname: lastname,
                    email: email,
                    created_at: firebase.firestore.FieldValue.serverTimestamp()
                })
                .then((docRef) => {
                    alert('The account successfully regiter');
                })
                .catch((error) => {
                    handleAuthError(error);
                });     

            })
            .catch((error) => {
                handleAuthError(error);
            });
    }


});

}


// ===== Friendly error helper =====
function isEmpty(v) {
  return v == null || v === '';
}

function handleAuthError(err) {
    console.error('Auth error:', err);
    const code = err?.code || '';
    if (code === 'auth/email-already-in-use') {
      alert('That email is already in use.');
    } else if (code === 'auth/weak-password') {
      alert('Password is too weak (min 6 chars).');
    } else if (code === 'auth/invalid-email') {
      alert('Please enter a valid email address.');
    } else if (code === 'auth/user-not-found' || code === 'auth/wrong-password') {
      alert('Incorrect email or password.');
    } else {
      alert(err?.message || 'Authentication failed.');
    }
}

